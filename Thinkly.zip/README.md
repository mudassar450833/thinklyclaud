# Thinkly AI — Website

A fast, zero-dependency static marketing site for **Thinkly AI** (custom AI chatbots, agents & automation). Built with plain HTML, CSS, and vanilla JavaScript — no build step, no framework — so it drops straight onto GitHub Pages or any static host.

## File structure

```
.
├── index.html        # Homepage
├── contact.html      # Contact page with a working, validated form
├── privacy.html      # Privacy Policy (template — review with counsel)
├── terms.html        # Terms of Service (template — review with counsel)
├── 404.html          # Branded not-found page (GitHub Pages serves this automatically)
├── styles.css        # All styles, shared by every page
├── main.js           # All behavior, shared by every page (guarded per-page)
├── favicon.svg       # Site icon
├── robots.txt        # Search-engine directives
├── sitemap.xml       # Sitemap for search engines
├── .nojekyll         # Tells GitHub Pages to serve files as-is
├── .gitignore
└── README.md
```

## Run locally

It's a static site — just open `index.html`, or serve the folder:

```bash
python3 -m http.server 8080    # then visit http://localhost:8080
# or
npx serve .
```

## Deploy to GitHub Pages

1. Create a new GitHub repository and push these files to the **root** of the `main` branch:
   ```bash
   git init
   git add .
   git commit -m "Thinkly AI website"
   git branch -M main
   git remote add origin https://github.com/<you>/<repo>.git
   git push -u origin main
   ```
2. In the repo, go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source → Deploy from a branch**, branch **`main`**, folder **`/ (root)`**, then **Save**.
4. After a minute your site is live at `https://<you>.github.io/<repo>/`.

> **Project sites vs. user sites:** if the URL has a subpath (`/<repo>/`), all internal links here are relative (`contact.html`, `index.html#services`), so they work without changes. The absolute URLs in `sitemap.xml`, `robots.txt`, and the `og:`/`canonical` meta tags use `https://thinkly.ai/` as a placeholder — update them to your real domain (or your Pages URL) for correct SEO and social previews.

### Using a custom domain
Add a file named `CNAME` containing your domain (e.g. `thinkly.ai`), point your DNS at GitHub Pages, then enable HTTPS in **Settings → Pages**.

## What changed vs. the original single file

The original was one 1,400-line `index.html`. This version keeps the same visual design but is restructured for real hosting and maintenance:

- **Split into shared assets** — `styles.css` and `main.js` are loaded by every page, so the browser caches them once and each HTML file stays small.
- **Fixed broken internal links** — the original linked to `/contact`, `/legal/privacy-policy`, and `/legal/terms-of-service`, which would 404 on GitHub Pages. Those pages now exist (`contact.html`, `privacy.html`, `terms.html`) and all links are relative.
- **Real contact page & form** — client-side validation, accessible inline errors, and success/error states. See "Wiring up the form" below.
- **Branded 404 page** — GitHub Pages serves `404.html` automatically for unknown paths.
- **Dynamic copyright year** — no more hardcoded `2025`; `main.js` fills it in from the current date.
- **SEO & social** — per-page `<title>`/descriptions, canonical URLs, Open Graph + Twitter cards, JSON-LD `Organization` data, `sitemap.xml`, and `robots.txt`.
- **Icons & polish** — an SVG favicon, hero image preload hint for faster LCP, and a corrected `<header role="banner">` landmark.
- **Robust JS** — every feature is guarded so the shared script runs safely on pages that don't contain that widget.

Accessibility carried over from the original is preserved: skip link, landmark roles, `aria-*` on interactive controls, keyboard focus styles, and `prefers-reduced-motion` support.

## Wiring up the contact form

The form works out of the box in **demo mode** (it validates and shows a success message without sending anything). To receive real submissions with no backend, use [Formspree](https://formspree.io):

1. Create a free Formspree form and copy its ID (the part after `/f/`, e.g. `xnqkvabc`).
2. In `main.js`, set:
   ```js
   var FORMSPREE_ID = 'xnqkvabc';
   ```
   That's it — submissions will POST to Formspree and land in your inbox.

Prefer your own API? Replace the `fetch(...)` call in the form handler in `main.js` with a request to your endpoint.

## Replacing placeholders before launch

- Domain: swap `https://thinkly.ai/` in `index.html`, `contact.html`, `privacy.html`, `terms.html`, `sitemap.xml`, and `robots.txt`.
- Social image: add an `og-image.png` (1200×630) to the root — it's referenced by the meta tags.
- Contact details: WhatsApp number (`+1 608 674 1667`) and email (`hello@thinkly.ai`) appear in the footer and contact page.
- Legal copy: `privacy.html` and `terms.html` are templates — review with legal counsel.
- The on-page chat widget uses canned replies for demonstration; connect it to your own chat backend if you want it live.

## License

© Thinkly. All rights reserved.
