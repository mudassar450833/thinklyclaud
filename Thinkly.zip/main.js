/* =====================================================================
   Thinkly AI — site scripts (shared across all pages)
   Every block is guarded so it no-ops on pages that lack those elements.
   ===================================================================== */
(function () {
  'use strict';

  /* ---------- Dynamic copyright year ---------- */
  document.querySelectorAll('[data-year]').forEach(function (el) {
    el.textContent = new Date().getFullYear();
  });

  /* ---------- Navbar background on scroll ---------- */
  var navbar = document.getElementById('navbar');
  if (navbar) {
    var onScroll = function () { navbar.classList.toggle('scrolled', window.scrollY > 20); };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  /* ---------- Hamburger / mobile menu ---------- */
  var hamburger = document.getElementById('hamburger');
  var mobileMenu = document.getElementById('mobile-menu');
  if (hamburger && mobileMenu) {
    hamburger.addEventListener('click', function () {
      var open = mobileMenu.classList.toggle('open');
      hamburger.setAttribute('aria-expanded', String(open));
    });
    mobileMenu.querySelectorAll('.mobile-link').forEach(function (link) {
      link.addEventListener('click', function () {
        mobileMenu.classList.remove('open');
        hamburger.setAttribute('aria-expanded', 'false');
      });
    });
  }

  /* ---------- Highlight current page in nav ---------- */
  (function () {
    var path = location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('[data-nav]').forEach(function (a) {
      if (a.getAttribute('data-nav') === path) a.classList.add('active');
    });
  })();

  /* ---------- FAQ (home only) ---------- */
  var faqList = document.getElementById('faq-list');
  if (faqList) {
    var faqs = [
      { cat: 'Getting Started', q: 'What kind of businesses does Thinkly work with?', a: 'We work with businesses of all sizes across healthcare and e-commerce — from growing startups to established enterprises looking to modernize their operations with AI.' },
      { cat: 'Technical', q: 'How long does implementation take?', a: 'Depending on complexity, most solutions are live within 2–6 weeks. Simple chatbots can be deployed in as little as 7 days.' },
      { cat: 'Getting Started', q: 'Will this replace our team?', a: 'No — Thinkly AI handles repetitive, time-consuming tasks so your team can focus on high-value strategic work.' },
      { cat: 'Technical', q: 'Is my data secure?', a: 'Absolutely. We use enterprise-grade encryption and never train models on your private data without explicit permission.' },
      { cat: 'Pricing', q: 'How do I get started?', a: 'Reach out via WhatsApp or the contact form. We\u2019ll schedule a free consultation to understand your needs.' }
    ];
    var currentCat = 'All';

    function renderFAQ() {
      var filtered = currentCat === 'All' ? faqs : faqs.filter(function (f) { return f.cat === currentCat; });
      faqList.innerHTML = filtered.map(function (f, i) {
        return '<div class="faq-item" id="faq-' + i + '" role="listitem">' +
          '<button class="faq-q" aria-expanded="false" aria-controls="faq-ans-' + i + '" data-faq="' + i + '">' +
          '<span>' + f.q + '</span>' +
          '<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>' +
          '</button>' +
          '<div class="faq-a" id="faq-ans-' + i + '" role="region"><p>' + f.a + '</p></div>' +
          '</div>';
      }).join('');
    }

    faqList.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-faq]');
      if (!btn) return;
      var item = btn.closest('.faq-item');
      var isOpen = item.classList.contains('open');
      faqList.querySelectorAll('.faq-item').forEach(function (el) {
        el.classList.remove('open');
        el.querySelector('.faq-q').setAttribute('aria-expanded', 'false');
      });
      if (!isOpen) {
        item.classList.add('open');
        btn.setAttribute('aria-expanded', 'true');
      }
    });

    document.querySelectorAll('.faq-tab').forEach(function (tab) {
      tab.addEventListener('click', function () {
        document.querySelectorAll('.faq-tab').forEach(function (t) {
          t.classList.remove('active'); t.setAttribute('aria-selected', 'false');
        });
        tab.classList.add('active');
        tab.setAttribute('aria-selected', 'true');
        currentCat = tab.dataset.cat;
        renderFAQ();
      });
    });

    renderFAQ();
  }

  /* ---------- Process accordion (home only) ---------- */
  var processSteps = document.querySelectorAll('.process-step');
  if (processSteps.length) {
    var processImgs = [
      'https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&w=1200&q=80'
    ];
    document.querySelectorAll('.process-step .step-header').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var step = btn.closest('.process-step');
        var wasActive = step.classList.contains('active');
        processSteps.forEach(function (s) {
          s.classList.remove('active');
          s.querySelector('.step-header').setAttribute('aria-expanded', 'false');
        });
        if (!wasActive) {
          step.classList.add('active');
          btn.setAttribute('aria-expanded', 'true');
          var idx = Array.prototype.indexOf.call(processSteps, step);
          var img = document.getElementById('process-img');
          if (img && processImgs[idx]) {
            img.src = processImgs[idx];
            var t = btn.querySelector('.step-title');
            if (t) img.alt = t.textContent;
          }
        }
      });
    });
  }

  /* ---------- Services horizontal scroll (home only) ---------- */
  var scroller = document.getElementById('services-scroll');
  var srvLeft = document.getElementById('srv-left');
  var srvRight = document.getElementById('srv-right');
  if (scroller && srvLeft && srvRight) {
    srvLeft.addEventListener('click', function () { scroller.scrollBy({ left: -360, behavior: 'smooth' }); });
    srvRight.addEventListener('click', function () { scroller.scrollBy({ left: 360, behavior: 'smooth' }); });
  }

  /* ---------- Chat widget (present on most pages) ---------- */
  var chatToggle = document.getElementById('chat-toggle');
  var chatBox = document.getElementById('chat-box');
  if (chatToggle && chatBox) {
    var chatClose = document.getElementById('chat-close');
    var chatInput = document.getElementById('chat-input');
    var chatSend = document.getElementById('chat-send');
    var chatMessages = document.getElementById('chat-messages');

    var botReplies = [
      'Great question! I\u2019d be happy to help you explore how AI can transform your operations.',
      'We offer custom solutions including AI chatbots, autonomous agents, workflow automation, and voice call agents.',
      'Most implementations go live in 2\u20136 weeks. Simple chatbots can be ready in as little as 7 days.',
      'Our pricing is custom-tailored. Contact us for a free consultation and we\u2019ll provide a detailed quote.',
      'You can reach us via WhatsApp at +1 608 674 1667 or use the contact form on our website.'
    ];
    var replyIndex = 0;

    var addBubble = function (text, role) {
      var div = document.createElement('div');
      div.className = 'chat-bubble ' + role;
      div.textContent = text;
      chatMessages.appendChild(div);
      chatMessages.scrollTop = chatMessages.scrollHeight;
    };

    chatToggle.addEventListener('click', function () {
      var open = chatBox.classList.toggle('open');
      chatToggle.setAttribute('aria-label', open ? 'Close chat' : 'Open AI chat');
      if (open && chatInput) chatInput.focus();
    });
    if (chatClose) chatClose.addEventListener('click', function () {
      chatBox.classList.remove('open');
      chatToggle.setAttribute('aria-label', 'Open AI chat');
    });

    var sendChatMessage = function () {
      if (!chatInput) return;
      var text = chatInput.value.trim();
      if (!text) return;
      addBubble(text, 'user');
      chatInput.value = '';
      setTimeout(function () {
        addBubble(botReplies[replyIndex % botReplies.length], 'bot');
        replyIndex++;
      }, 700);
    };
    if (chatSend) chatSend.addEventListener('click', sendChatMessage);
    if (chatInput) chatInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') sendChatMessage();
    });
  }

  /* ---------- Contact form (contact page only) ---------- */
  var form = document.getElementById('contact-form');
  if (form) {
    var status = document.getElementById('form-status');
    var FORMSPREE_ID = ''; // <-- Paste your Formspree form ID here (e.g. "xnqkvabc"). Empty = demo mode.

    var showFieldError = function (field, msg) {
      field.classList.add('invalid');
      var err = field.querySelector('.form-error');
      if (err) err.textContent = msg;
    };
    var clearFieldError = function (field) {
      field.classList.remove('invalid');
      var err = field.querySelector('.form-error');
      if (err) err.textContent = '';
    };

    form.querySelectorAll('.form-control').forEach(function (input) {
      input.addEventListener('input', function () { clearFieldError(input.closest('.form-field')); });
    });

    var setStatus = function (type, msg) {
      if (!status) return;
      status.className = 'form-status show ' + type;
      status.textContent = msg;
    };

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (status) status.className = 'form-status';

      var valid = true;
      var emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      form.querySelectorAll('[required]').forEach(function (input) {
        var field = input.closest('.form-field');
        var val = input.value.trim();
        if (!val) { showFieldError(field, 'This field is required.'); valid = false; }
        else if (input.type === 'email' && !emailRe.test(val)) {
          showFieldError(field, 'Enter a valid email address.'); valid = false;
        } else { clearFieldError(field); }
      });

      if (!valid) {
        var firstBad = form.querySelector('.form-field.invalid .form-control');
        if (firstBad) firstBad.focus();
        return;
      }

      var btn = form.querySelector('.form-submit');
      var original = btn ? btn.textContent : '';
      if (btn) { btn.disabled = true; btn.textContent = 'Sending…'; }

      var done = function (ok) {
        if (btn) { btn.disabled = false; btn.textContent = original; }
        if (ok) {
          form.reset();
          setStatus('success', 'Thanks — your message is on its way. We\u2019ll reply within one business day.');
        } else {
          setStatus('error', 'Something went wrong. Please email hello@thinkly.ai or message us on WhatsApp.');
        }
      };

      // If no Formspree ID is configured, run in demo mode (no network call).
      if (!FORMSPREE_ID) {
        setTimeout(function () { done(true); }, 700);
        return;
      }

      fetch('https://formspree.io/f/' + FORMSPREE_ID, {
        method: 'POST',
        headers: { 'Accept': 'application/json' },
        body: new FormData(form)
      }).then(function (r) { done(r.ok); }).catch(function () { done(false); });
    });
  }

  /* ---------- Scroll-reveal (fade-up) ---------- */
  var fadeEls = document.querySelectorAll('.fade-up');
  if (fadeEls.length && typeof IntersectionObserver !== 'undefined') {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) { entry.target.classList.add('visible'); io.unobserve(entry.target); }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
    fadeEls.forEach(function (el) { io.observe(el); });
  } else {
    fadeEls.forEach(function (el) { el.classList.add('visible'); });
  }
})();
